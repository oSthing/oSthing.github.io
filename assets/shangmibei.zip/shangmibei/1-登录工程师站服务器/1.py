import requests
import json

# 替换为实际的工程师站服务器 IP
IP = "192.168.10.17"
# 成功登录工程师站服务器后，可通过浏览器开发者工具查找到
TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE3ODUwMzc5NzAsInVzZXJuYW1lIjoiQm9iIn0.eahJz5A0SB33XAYtJAHyWvoFDPRssjfeX3DjQaL8R0A"
def string_xor(str1, str2):
    xor_result = ''.join(chr(ord(a) ^ ord(b)) for a, b in zip(str1, str2))
    return xor_result

str1 = "Hello"
str2 = "World"

result = string_xor(str1, str2)

if __name__ == "__main__":
    url = f"http://{IP}:5000/api/encrypt"

    
    payload = json.dumps({
        "plaintext": "123"
    })
    headers = {
        'Authorization': TOKEN,
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)
    

    print(response.text)
# 123 {"ciphertext":"ebc444","iv":"eb032da9bd6b4c0f4a11b3fe26232dcb"}
# 
