#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "sdk/include/sdf_cryptoapi_ex.h"

void *devHandle = NULL;
void *sessionHandle = NULL;
void *keyHandle = NULL;

int open_session() {
    int ret = 0;

    //打开设备
    ret = SDF_OpenDevice_ex(&devHandle,"192.168.10.15 ",9190);
    if (ret) {
        printf("SDF_OpenDeviceWithPath error, ret=%08x\n", ret);
        return ret;
    }

    //打开会话
    ret = SDF_OpenSession(devHandle, &sessionHandle);
    if (ret) {
        printf("SDF_OpenSession error, ret=%08x\n", ret);
        SDF_CloseDevice(devHandle);
        return ret;
    }
    return ret;
}

int close_session() {
    //关闭会话
    int ret = 0;
    ret = SDF_CloseSession(sessionHandle);
    if (ret) {
        printf("SDF_CloseSession error, ret=%08x\n", ret);
        SDF_CloseDevice(devHandle);
        return ret;
    }

    //关闭设备
    ret = SDF_CloseDevice(devHandle);
    if (ret) {
        printf("SDF_CloseDevice error, ret=%08x\n", ret);
        return ret;
    }
    return ret;
}

int init() {
    int ret = 0;
    ret = open_session();
    if (ret) {
        printf("open_session error, ret=%08x\n", ret);
        return ret;
    }
    return 0;
}

int destroy() {
    int ret = 0;

    ret = close_session();
    if (ret) {
        printf("[ts_symm] close_session error, ret=%08x\n", ret);
        return ret;
    }
    return 0;
}

int hex_string_to_char_array(const char *hex, unsigned char *out) {
    size_t hex_len = strlen(hex);
    if (hex_len % 2 != 0) return -1; // 奇数长度报错

    for (size_t i = 0; i < hex_len; i += 2) {
        unsigned int byte;
        if (sscanf(hex + i, "%2X", &byte) != 1) return -1; // 解析失败
        out[i / 2] = (unsigned char) byte;
    }
    return hex_len / 2; // 返回转换后的字节数
}

size_t ECCCipher_serialize(const ECCCipher *cipher, unsigned char *out) {
    size_t offset = 0;

    // 0. 04 前缀
    out[0] = 0x04;
    offset += 1;

    // 1. C1
    memcpy(out + offset, cipher->x + 32, 32);
    offset += 32;

    memcpy(out + offset, cipher->y + 32, 32);
    offset += 32;

    // 2. C3
    memcpy(out + offset, cipher->M, 32);
    offset += 32;

    // 3. C2
    memcpy(out + offset, cipher->C, 16);
    offset += 16;

    return offset; // 返回序列化后总长度
}

const char hex_table[] = "0123456789ABCDEF";

void char_array_to_hex_string(const unsigned char *src, size_t len, char *dst) {
    for (size_t i = 0; i < len; i++) {
        dst[2 * i] = hex_table[(src[i] >> 4) & 0x0F];
        dst[2 * i + 1] = hex_table[src[i] & 0x0F];
    }
    dst[2 * len] = '\0';
}

int main(int argc, char *argv[]) {
    int ret = 0;

    ret = init();
    if (ret) {
        printf("init error, ret=%08x\n", ret);
        return ret;
    }

    // 调用密码机进行具体的密码运算

    ret = destroy();
    if (ret) {
        printf("destroy error, ret=%08x\n", ret);
    }
    return 0;
}
