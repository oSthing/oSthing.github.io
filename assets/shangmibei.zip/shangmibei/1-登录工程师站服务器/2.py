"""

参数:
    n     = 17669   (环维度，要求为素数（保证 X^n-1 在 GF(2) 上仅有两个不可约因子）)
    k     = 16      (消息长度，字节)
    n1    = 46      (外码 RS[46, 16, 31] 的码长)
    n2    = 384     (内码重复 RM 的码长（RM(1,7)×3 = [384, 8, 192]）)
    delta = 15      (RS纠错能力)
    w     = 66      (私钥向量 x, y 的 Hamming 重量)
    w_r   = 75      (随机向量 r1, r2 的 Hamming 重量)
    w_e   = 75      (误差向量 e 的 Hamming 重量)
    级联码结构：RS[46,16,31] over GF(2^8) ⊗ RM(1,7)×3
"""

import os, hashlib, random
from typing import Tuple, List

# ============================================================
# 参数
# ============================================================
PARAM_N     = 17669     # 环 R = GF(2)[X]/(X^17669 - 1) 的维度
PARAM_K     = 16        # 消息长度 (字节)
PARAM_N1    = 46        # 外码 RS[46, 16, 31] 的码长
PARAM_N2    = 384       # 内码重复 RM 的码长（RM(1,7)×3 = [384, 8, 192]）
PARAM_DELTA = 15        # RS可纠错数
PARAM_W     = 66        # 私钥向量 x, y 的 Hamming 重量
PARAM_W_R   = 75        # 随机向量 r1, r2 的 Hamming 重量
PARAM_W_E   = 75        # 误差向量 e 的 Hamming 重量
PARAM_RM_M  = 7         # RM(1,m) 
PARAM_RM_LEN = 128      # RM(1,7) 码长 = 2^7
PARAM_REP   = 3         # RM 码重复次数

# GF(2^8) 不可约多项式: x^8 + x^4 + x^3 + x^2 + 1 = 0x11D
GF256_MOD = 0x11D

# ============================================================
# Reed-Muller RM(1,7) 编码与解码
# ============================================================
# RM(1,7) 是一阶 Reed-Muller 码，参数为 [128, 8, 64]：
#   码长  n = 2^7 = 128
#   维度  k = 1 + 7 = 8（常数项 + 7 个坐标函数）
#   最小距离 d = 2^(7-1) = 64

def rm17_encode(symbol: int) -> int:
    """
    RM(1,7) 编码：8 位符号 → 128 位码字。
    符号格式：bit7 = 常数项，bits[6:0] = 线性项系数。
    """
    codeword = 0
    const_bit = (symbol >> 7) & 1  # 最高位 = 常数项
    for pt in range(128):  # 在所有点评估仿射函数
        val = const_bit
        for bit in range(7):
            if (symbol >> bit) & 1:
                val ^= (pt >> bit) & 1
        if val:
            codeword |= (1 << pt)
    return codeword

def rm17_decode(codeword: int) -> int:
    """
    RM(1,7) 解码：128 位码字 → 8 位符号（Walsh-Hadamard 变换）。
    """
    # Map {0,1} -> {+1,-1}
    signal = [1 - 2 * ((codeword >> i) & 1) for i in range(128)]
    # 快速Walsh-Hadamard变换
    wht = list(signal)
    h_step = 1
    while h_step < 128:
        for i in range(0, 128, h_step * 2):
            for j in range(i, i + h_step):
                x, y = wht[j], wht[j + h_step]
                wht[j], wht[j + h_step] = x + y, x - y
        h_step *= 2
    # 找到绝对值最大值
    best_idx = max(range(128), key=lambda i: abs(wht[i]))
    sign_bit = 1 if wht[best_idx] < 0 else 0
    return (sign_bit << 7) | best_idx

# ============================================================
# 重复 Reed-Muller 码 [384, 8, 192] = RM(1,7) × 3
# ============================================================
# 将 RM(1,7) 码重复 3 次：
#   编码：128 位码字复制 3 份，拼接为 384 位
#   解码：将 3 份 128 位段逐位取多数表决（bitwise majority vote），
#          再调用 RM(1,7) 解码
# 重复设计将最小距离从 64 提升至 192，代价是码率降低为 1/3

def dup_rm_encode(symbol: int) -> int:
    """重复 RM(1,7)×3 编码：8 位符号 → 384 位码字。"""
    base = rm17_encode(symbol)
    return base | (base << 128) | (base << 256)

def dup_rm_decode(bits: int) -> int:
    """重复 RM(1,7)×3 解码：384 位码字 → 8 位符号。"""
    mask = (1 << 128) - 1
    seg0 = bits & mask
    seg1 = (bits >> 128) & mask
    seg2 = (bits >> 256) & mask
    # 按位多数表决
    majority = (seg0 & seg1) | (seg1 & seg2) | (seg0 & seg2)
    return rm17_decode(majority)

# ============================================================
# Reed-Solomon RS[46, 16, 31] over GF(2^8)
# ============================================================
# RS 码参数：
#   码长  n1 = 46，信息位 k = 16，最小距离 d = 31
#   纠错能力 δ = (d-1)/2 = 15 个 GF(2^8) 符号
# 系统码形式：码字 = [消息符号 | 校验符号]，前 16 个符号即为原始消息
_rs_codec = reedsolo.RSCodec(nsym=PARAM_N1 - PARAM_K, fcr=1, c_exp=8)  # 默认 GF(2^8)

def rs_encode(msg: bytes) -> List[int]:
    """编码：消息 -> 系统码码字（消息 + 校验）"""
    if len(msg) != PARAM_K:
        raise ValueError(f"消息长度必须为 {PARAM_K} 字节")
    encoded_bytes = _rs_codec.encode(msg)
    return list(encoded_bytes)

def rs_decode(symbols: List[int]) -> bytes:
    if len(symbols) != PARAM_N1:
        raise ValueError(f"接收码字长度必须为 {PARAM_N1} 个符号")
    received_bytes = bytes(symbols)
    try:
        # 兼容不同版本 reedsolo 的返回值
        decoded_bytes = _rs_codec.decode(received_bytes)[0]
    except reedsolo.ReedSolomonError as e:
        raise ValueError(f"RS解码失败：{e}") from e
    return decoded_bytes[:PARAM_K]

# ============================================================
# 级联码 Concatenated Code 编码与解码
# ============================================================
# 编码流程（外码先行）：
#   16 字节消息
#   → RS[46,16,31] 外码编码 → 46 个 GF(2^8) 符号
#   → 每个符号经 dup_rm_encode → 46 × 384 = 17664 位
#   → 嵌入 n=17669 维环 R 中
#
# 解码流程（内码先行）：
#   17664+ 位码字
#   → 按 384 位分组为 46 组，每组经 dup_rm_decode → 46 个 GF(2^8) 符号
#   → RS 解码（综合征检验 + 可选 BM 纠错）→ 16 字节消息

def concat_encode(msg: bytes) -> int:
    """级联码编码：16 字节消息 → 17664 位码字（Python 整数形式）。"""
    rs_symbols = rs_encode(msg)
    codeword = 0
    for i, sym in enumerate(rs_symbols):
        inner = dup_rm_encode(sym)
        codeword |= (inner << (i * PARAM_N2))
    return codeword

def concat_decode(codeword: int) -> bytes:
    """级联码解码：17664+ 位码字（Python 整数）→ 16 字节消息。"""
    symbols = []
    for i in range(PARAM_N1):
        chunk = (codeword >> (i * PARAM_N2)) & ((1 << PARAM_N2) - 1)
        symbols.append(dup_rm_decode(chunk))
    return rs_decode(symbols)

# ============================================================
# 多项式环 R = GF(2)[X]/(X^n - 1) 上的运算
# ============================================================
# 全部公钥/密文运算均在此环上进行。
# 元素以 Python 整数表示：第 i 位对应 X^i 的系数。
# 重要性质：
#   加法 = XOR（GF(2) 特征为 2，加减等价）
#   乘法 = 循环卷积（模 X^n - 1 的多项式乘法）
#   公钥 s = x + h·y 的安全性依赖于求解 QCSD 问题的困难性

def poly_add(a: int, b: int) -> int:
    return a ^ b

def poly_mul_mod(a: int, b: int, n: int = PARAM_N) -> int:
    """
    循环多项式乘法：(a · b) mod (X^n - 1)。
    实现策略：枚举 a 的非零位（稀疏乘法），对 b 施加相应的循环移位后 XOR 累加。
    时间复杂度 O(wt(a) · n)，适合 Hamming 重量较小的向量（如私钥和随机向量）。
    """
    result = 0
    mask = (1 << n) - 1
    # 优化：遍历a的置位
    temp = a
    i = 0
    while temp:
        if temp & 1:
            shifted = b << i
            result ^= (shifted & mask) ^ (shifted >> n)
        temp >>= 1
        i += 1
    return result & mask

def poly_weight(a: int) -> int:
    return bin(a).count("1")

def poly_to_bytes(p: int) -> bytes:
    return p.to_bytes((PARAM_N + 7) // 8, "little")

def poly_from_bytes(data: bytes) -> int:
    return int.from_bytes(data, "little") & ((1 << PARAM_N) - 1)

# ============================================================
# 随机向量采样
# ============================================================
# 安全性要求密钥和随机向量的 Hamming 重量精确固定。
# 采样算法：从 {0,...,n-1} 中均匀无重复地抽取 w 个位置，置为 1。

def sample_fixed_weight(n: int, w: int, rng=None) -> int:
    """采样 Hamming 重量恰好为 w 的随机二进制向量。"""
    if rng is None: rng = random.SystemRandom()
    positions = rng.sample(range(n), w)
    result = 0
    for p in positions: result |= (1 << p)
    return result

def sample_random_poly(n: int, rng=None) -> int:
    """采样均匀随机的 n 位多项式（用于公钥 h 的生成）。"""
    nbytes = (n + 7) // 8
    if rng is None:
        raw = os.urandom(nbytes)
    else:
        raw = bytes(rng.getrandbits(8) for _ in range(nbytes))
    return int.from_bytes(raw, "little") & ((1 << n) - 1)

# ============================================================
# 密钥生成/封装
# ============================================================

def keygen(seed: bytes = None) -> Tuple[dict, dict]:
    """
    密钥生成。
    公钥 pk = (h, s)：h 为均匀随机多项式，s = x + h·y
    私钥 sk = (x, y)：两个 Hamming 重量为 w 的低权重多项式
    安全性基于求解 2-QCSD 问题的困难性。
    """
    if seed:
        rng = random.Random(seed)
    else:
        rng = random.SystemRandom()
    h = sample_random_poly(PARAM_N, rng)
    x = sample_fixed_weight(PARAM_N, PARAM_W, rng)
    y = sample_fixed_weight(PARAM_N, PARAM_W, rng)
    s = poly_add(x, poly_mul_mod(h, y))
    return {"h": h, "s": s}, {"x": x, "y": y}

def encapsulate(pk: dict, m: bytes, r1: int, r2: int, e: int):
    h, s = pk["h"], pk["s"]
    u = poly_add(r1, poly_mul_mod(h, r2))
    v = poly_add(poly_add(concat_encode(m), poly_mul_mod(s, r2)), e)
    shared_key = hashlib.sha512(m).digest()[:32]
    return u, v, shared_key


m = bytes.fromhex("11111111111111111111111111111111")  # 输入消息
h=b'c89c10c06d8de5d7bed8c6f57f376923c18828c28c6d26a61f07638028b1c374602a93aa09893c4ffa0067747ca3906f5ada788e5590e2233a9198b7d297b217a69e5092ab67c77b4a664488e33ef63972056de0298f8e79c01a57a8edd643023a2d84480ab568e05964d578b90e22337797dda1c3b9b39f3a67c553a4e2164b8f09693aba4e1af4875e8b3ed36d96de417cbd9a2e71a37157d55270ed91bdc5324503518ba8879b16ee025b56155ddcce55cd078d4f990e82e9fb0964b845dc97095a16fc332022e61d290aa48bee4a699e07cbffd67e3bd1ace32895b8e6abc7f9051d66acc69bf37244f14be38103d7e5da0b6a69637a8bc8c88ba8c46579cfdd8ce9da3c3c1e86df7148f88723768dce90080a6a1e2a5635d3d0752724bdd0ef170906cd69d860e979fe5c5ae089fdc664f1211ebd80008dcbefd5cbf7ae59396d2156ec84650f0dc9cfbe06d6dec81868fc738556153a4675bf27f98e2e890eb62c704c49cf195f72bbfd9fa51b98e3a7ee5461dd806cdbda01341ab9e71df27a767962bb49d8b2e785bb8106a84a46fa60a57f75183d73eb6176b752312ef7f54d224ebdb8dd864e53df3b4427b7b609cb8545ed041ee9c7119a7998343ba9a91854574f8bd2ecae7350a35aab74de26caa028d93e67dc93604709b0edb733356e272d2c403cf1d42ed25e60af991e1d360b77e8cf13f18b7ae7955049c36007c69b28d91c9be9e4af27a2c455e2dc9701bb05c4ac65dd8f5eaee23b441613add87fafffef223dc578b39cb65b20a20603c893486db4ceadbf5de64e28662c9a94e030f8f51ce0c3410d85fd4bb6a3568d8b2436ed19018d157b85cf3e33f8dc8921851fde9da6999d7ab9946f1424e73229ae0a2f49d1babda3ca39388d4bc001001f7c0be608672cef6d80fb45986f9e486ec736246bcebfcefd24170726f34a4ef469afbfc5ccbce0f68131431892f0163d220c0d423921f97bbf05f336aa52ed3d27808d3708a0f2f9ec020ded6cf0e0974412dcf62061cc3ffe698a28d86e26f61b0b38076394c7ec9ba7df1aba90fdacd6eb90a805a0d7f3766c336a25ef6552f3bd9260c8045d85f6f43adc45efa019f7ceab540125c2a68febad936b914336e2118408b26b9635bc1e2dcc7eccfff158cfa8aeb1507c8d4f9a1c60917367681a57b6dee35163fcc19c5dafdbd5894b2c3330473309c8d2a8163a91d1f28cc3d1c0d0bcce256262af86b73627e2ea73f23cc170cbde68314971aa473a41473a111118de4dbd1383621fb085d5667c902a4a59be36a869451171d9632905a66d54d09731db24f21d61c9f95e58145328a1045f0ae84b09a6c040cd19b02ed7afec2a0b0b54aff40a342da7887a34cfb9e1fc11008042120c772469c888632d5f17552bb9a97b284fba4167c7782b9ae24b45efeefd4bdf99c21e39e4f3d44bf407279eb26cea4fd20a6d17771f86d6ddd14a09c383ecc52bf69eb2f4047e926ed51fa2e7d7d1040d33ce9d1abe9caa5f35c89457926bb1df04b0b2553b58de5b459f4100789140fa4f90c529231c6e45a84f6efbee55de98c743a3e3f12a1b870417a96543e1960fa5af972940f1f0139e1348882d23f4892229b5447a196a386c581337a4ebcf2df8943d14f7586d302cab7581d04fb661e92be900bde6157e0fa8b794c5d56b6ebe25951f059cadeb6c2ef931d228f735c582b24e7bc2082527da3fc7e6eb65faae55e77bb22b5d05113c68b4f195a2be7de86ec7c8f1482962a5f4b1ad53595a7f0c90e38c3497e3c8b0794d481e13e142fce5a728c4c48352bb543f406e640af00eecf446cc313e188b7465a5ca3e442c9ad9150a30245d0d894c0f983b4c858d5405f0574b730ca2b8e7c6d4482ae50a20a85cf006468fc9987f55c254b9bc8c31f6e4bffe63ac3ae05f8de9708dc8762bafd46a7f852140e63b314dfcc66b42cdfc17cea8af099fc1388ffbbe6046396ac28b99bc2875f95d0d19f09869cbcfb6baf3848b3b644efb4b729edacda630a8cd33d6957382fd8f6b0531be5419c1a6058f7dc70db290f48ea476a9a8a2ac9d3d79a23817aa7b2a83789265f7d580728016ba76cd6d6ea4c6a813b91af88fd9d4eb5bb8fe9853dd2b6a471983b52847a1fc7e1c27c3c6120d3b83342cd56bcffd576590980225e93e74e8c17f46dfee377dbf06aca1375a6256af5cea12ee2c53c34c2dc0500ddd406678fe6a0e28b642cd65e7f7c58029d1541fe57f8bb15099de37bcabf82f6e65170256ef6b67853bd58fe2adaf528be1fd65953fe5b940d33cec0a6e9f4290a89181a61f1bc8db1e8b511099f0ef2264b3643c8bc2cb8fdd17b107216883205f2c0c1f2d2cc9f5bd43b0d085c6df24dc7b2792ad1044247c1ee45a1a1ccbfd70098c312f9c7060ff6bf07ab2f21c2c312a4db078be2d8cbc65c32c01fb7ef733c7a6e6badd0f1224b5e2a26b8eebfd6da2229f0e7720f406da02565fc725c8cf24d3dfc2977666dd96d07ba62c8f44aa7b0db620bd3b2dd868f38d329f3411a43388d292528dee82d9cf23ff594f53ec9bd017b307fd836fba60bd39d387c5ae7684563b6017019928f05e2769e02280d0d32907be466fb3f449ded9ebc265e9714fe33908ebdd90e9efcdac33166bf9fad651bfa6421ae575640b2d229128467962bdb4a260ff03a8a74e1a8bbd7a617fbbf454a548abcb9d7ade828db6865b59e9fbec9bef465b1238bb78b9d094f922c3064f76a2ab3e60edfa509533c92f18cacc8953cc1ad86941edb96253ba96707a6589400a46193c8804e1f41e5fa3da57da0f3a6fa20ef9d3e39d7bfea22192434f771d4d24751fb53bc570307254d32b07a5e6fea51bee806b7533126b5b5faea5d055bab64d28cedb6c7eb3f8cbdef05f1020b65f418b9b3970412789da313ba441315f3d0061b12579a2a93db1a72dff270c05583809053e888c65adc3f88fa67ccfb674bfe1a6ba691bc2c858c794ee35af2e0ac5a1bdcf2801a48db7afd69927c212bcca711ca9b9b8ef2a72abbf1527297b1c30cc8feeec386c73c24472459435af6ed17fbe266651fe4b62324986c44c0052b53bae4e726c97dde378b6556ab9d0b616'
s=b'79a1ca5df6f7a4bcf43de0ef47abf04e6c431e11e255ee70103db9050ad1fb4967c27ed5ce73fb09c6c1c018344c95813e11ae6d36f0bda594a6850df029af5b0995ada3ab3608b5af0c1f309e2a14a67c7b66eed02b02ff2f54e70cabf721188e812170197f3833a0f167030e706d3e200a69b5eb5e7aa9b65a3eaf19da8733523d5b0d8a6071ebef0fd2d97336004a31cba326f142c12697f138ac465bb95c82bc9b6b0a8bd30ee225445fe2b6896cfab3c784ff143b1afa7956c013f73be60484ec40491ace736ed6f6b57c3c788bf41fbc45da6632b32d3bb0a7413f0b8f83b44c205fd8ab79e0da040f36df2046ccca9127ecc7d5f3635228269e0e56702997cf0ad88dcec70a1caf1d9869df7ad21770ade61eb8cf7595e01bc3784441ae0c2eb0e098e2b8efd7dfd40d0509b7413e3ee2cbf88a3ab83a68b0f2e6e22405b96b3975b73d2bdac058b2a9f40b158870e83751afbbecbf283f9a0ff71423f61b430d81f0ab3d0cb5a84afe9c7f3ef20d9c3d3e829c43d52c7d2dabf070bcc09dd31341f999d9fdc1c0dc4dbaf3d45551cdd4307cdb950a84bc4777ac08de6cb488efffa596f7dba6d285ef4fb1e007d75064df07b6031fbe25bbf6b6ce1692bb8426ae21c99c94fe316508f7eb464c7cd8ad0ee280af9bef7462da3c23cdb19ba352e1ba63f73fa29fc0e9145cbe9c68cb047db62d5763d6abe722f5109cf04ab1d887326aa86124aaa8f9ecc9e8dd3742622a6a901dbcc8941e54efc51706244ff6b6c560114218e114ee9975cd2e9b8414158b7308011a81eedf4eb1c3dd7d693dee4db62c30ded2e1ac1d008462569c9d93ecd6c62cd06941ba7d6ec278686b82958ca76294e29da390c5d4cd1436a344647c1cb0d6ca13556bd7abfd27993ebea798c254b3dbe0db7ac001168aa5343311288d0b923fbf5a168b6d5e7cbb85fef4c41f0e630618f2b38075d03fc1fcbeeb64be0fa0638da261d7bedb8641048a24c9627a8f893c7e8f11ee129840e8ecbc4cccef0cb05c70d611a1b61c95cfde6ed63021e31eadcccc6bf02c06313c6b60745d09d8ad04db0de83208bb73368ca8c51e4e5a51a6d45599529478270a76c5667a799a1c6737f2df0b16f8791a09e5b0a5c821d7857bc7df0dc0969ea293f83228f536518097b7862da60f135b9421960198d5b8856fa38a8d18430214aa3cfca0e0784611e109884134e3f6c3c56541c940d6aa6dbb3ffe5bf05aa18f04805714c0dd812683a251196cec9ab319e1042b282d68e522fdc65ba136c937412e112e5bc811587fe0fcef043b43482da92f9fe815b595b30b69726d18105348d2c4877df6394d5712b2852cf0b82be0b3ec95d42f85b204d948ff569ae3bec3c856af70fafa60d20768b8e17e71a82b8ce88048b3ae6f45604c3c0aaf91918071ade5680477576d1fb76115b77520b429756d00da1731223c71a902893489810263d78d1d6f248fe0b0f6ae9601aa68433906634d7cf19c045545522f45ca05164c6a421d47e20ea796a077d3a2b8cb8c57c173c4030e00ea6c879644d3bd63f45d03a05548724bb56b109148f2ce2e9b27d28fa84e4f560cd710adee39ee87ba525757b59292b5bfa97debf52516ca949c0510587f968fb2ddc230e9281bd43f5fc29ffe1aab9ba047315dd9bd4f79d16011ef27338d75fb21082829b50f18554ddd4b5da0ddf9109964d45be9b080cc6bf0e3219a99b2b82d6ae82ef96ddf52b5504246705b8ce527e7ae18bf3ad8e75c4c857489c2cf82671a4852fb9b7e69658762473cb76479208c941b5b02fd6270d801fc5d474d723520220c80ac6faea2c4396d95e58e2f3d6df49c69708cfa904ce8b1049eb8c9b78e94e930b8a88d76894a47017987720b8158c2e541f161a22a7647ffe15aa4fa50c0620af8e1f598d60831a8abebc297e6d69cd03b65ff9fce9574777b73bc98243afb695ac88cc67df8b6cccea8738a3c6cf851e3bb88c10643c72735ded763d5be29c974cb1ba2ff71ee878b8b4b0898276d8e4d2340514299572f578818ff479c8dd343047e43a6d41f67fa92e19931b30c1d6534f225ed6c5bbbd163b10b1713c0521c0b0ea2d33e02b06888ede0846bc24a68cd3ef9d5a3cd289e720d7ab5e0836c9623fac11cad3f1fe86fb0a8feb15f34849fbf0b1856453ad58da0087025f9d14c931ef6ff62f55abfa1da68ec7a89d8e6c85d503296782fbd908c13b3b83f133335364fd29bc8d09e98511c959df843a09e7d7aa389bb8b8f93569374d08d28cd2c7dcf3c62e5d83b942ee78d37818e1bbcd103ef563b3496052a81962efec2247f142ac31590eb7ffe98f6b0b255aea387c3ab9fe5d49a96a4600add24a106aeea01dadcaab3115a7a78d9b0ff536afe351059e235ac474ce1655cd9ce7d28fda13323767161cbb8eb02e47c0a4be73cb3a9e6c8392363a298e9e95135700ef65d6f4846924408f24ea848bf35b59ffb3aa6704ef233b7e7832f7f39db123928cae4900616b1420af35a834b2c55a4f8fb992638dc2fb1ae58fcd1aade41d4a20264590b03ca45a73359d7b2072880608be0628d6031ddab46b0695fa24a4d1358d3df8042644d5f35a158323b0303c3e6b738c195622973d7b1e859bc22072e37fe5b7ab6752a1d6c3664315b33dd5125eda6f9aaa2f6f6a7b3d5059a8ea74784d24bf5895f3bf6113c026a2072be40172557891ca84ab4d6a9ab94694c7f58d13c5df915e048fbd96effab43a92e37e128c4b3e0b98c0ccb24e1edd1f2ed6f3b67a3b4b2f743cbd0be7df742456487ef68ecf2e0c6bb86d4a84d62389db7b0f915ae8f032e6fbea7db838672a55e18893a2582ff320e2c6cf29e38a19d769e61ecd801a6035ef14ebc1a60f9d1a66aa3a671ccad2a4f86bf48fd9f8d399f1498aadc1688da485efcba91ac112c1886cf0e46bb3c8f6e8004f957b55c328369bf599b5bbc2bf7b9fcbd24aacb615003dbe74e31a8ec6f0d895cb7faa9da37d8e27e390e7a99e28a172f757a7eda77ee8ba0adab4b91693952ee6830d31d14fe493fe57fda5357b4a495f144bac2a1822c2ba40a0e1f9f789ebc66f25236286188394dfdb9fce9faccad8e141a17'
pk = {"h": int.from_bytes(h, "little"), "s": int.from_bytes(s, "little")}  # 公钥 h 和 s 的 16 进制表示
u = int.from_bytes(b"8c10f72f142262a3ffac585ebac19e79a7fdbadf406c528f93f563477a611c5e175adecd0f25a9f4c72be7211b6bc558fca002d673d34d4446919359f2bbc024f6c2a9cfd621e6a52c32d9ca4863948aba0f90af9a2345aa0b7078a5bc4f215deb66e9b38698bd9f1564379f0e38bf5b97d394877050e2360018e4dca1294f8f8cf46fb7ce96929cf41c1695d1b6c28420a1b55ed15bc2e8b39a90fbc950ee61fe26e3b0d97aab8ecfa73d826a97a3f8b2362852b4260e13440964b4b5d12eb23fbd4a50e06dbc14ec575e785364482b674749897db8e8484783e191023a47f9771541e2cd43c4e3b65af3e80f8dbb81fa76535bfa93a1d17de4bbf4bfbd69147f1a4664b91ea44dfb02669a9223b9fff0498169340132cd5a6e85c358ca5f66bc948a1644b1ec1acae8366ff24d766f766b845d102bafb96635e42a885e202e452e2569e02aaa9c0b08695ebf8ea2e9736868dfc0b0f2067025e5a51c75e3bae42d7ae6af4bd6783d511446d1b49085e9f3f870c3c6f0a6b6aa5e63b558bdf0aa05a8d0cfd73b241b524ab9cfdc8997eea3ae827453723b3217df40513bae54437dd85fb063db465d8c67a4ef0442362bb5897df0f122977a43d42a5e34da582d69287814fe86469e9123b2c1faf6dff4474826c5ce3e3189b9741c85b022e6c9ab3ccfbc6b9092e7b1364eb234217a9a001c00bb5427659bdcf6455e1cec7846d8c9e9ff5ab727a398751be8109c8bb4059275dbf38381251c257af64a60dc330c1be6350a8f81a040e5b59fc3fb775ae164e6f167baef7b93118d05c58a7e296af86efd697417b0cfd27e96ed238f56229a450eb53426456b0db95bfec1a383535b6433c4b8139ba81753ef1b44ae119786af1692b160962f808b5e15fd6f3a733f43470f6adce663f1557633fbedc000eac92c902ed97e7b1ed73d68b4cce247bd697ae39aecf8b4cb271dc9ea5325bbac2e2da8b18906d6b6179111c6672c11bef3293be2c3697b8cc0222f7a171d8cbec4996d949e27f3cbea3bfcb8edf1bacf2477e7446827147562e8f2b5b119d2eae4a125fe281ab1ff012a54d988918ec526d058b9e018600d480354738cc410695435df236db7c2fdf082e50d247364f1819348c8bc833f5ed5a06c21b8255b7fc4c722a7de3d65523db3aa42c4c1db4a987bc01ba50a66def4cd42dfa8a68eed87f6743983b6437a8ddda97d81757e325568bd09718fa90f68f637ef61e98bdac41c2f4eb44c9702d30e06c012ea5c294a859ee2960c6af9d44faea16cf986b9c214c37ff3c302d1f83cfc13a1105beda3b82d71852121f70b6217f46332d23ceee41c002b0e1dfed88fe29191d8bd540a28b3e5a55b53e3e20067f1da613c6268ff4a6d6050822ee1a7834a9879253e8b165b63c86aae6255f12938f8d45925980ac17226e422cd9851edcb567f82c84fb845efbc7572bb0fff716dcd6db236cb5066c2fa858c431e5af112f56e1b23aaf3d309a7e4fad08fe871eece858af349eddd61044bf1b65ad04ad7838b83d33ba3448ca9e3e8336bf82826c936f4e2d81edc8bd190e33afb319d07b0876f2456825e229e1729b991705e2f68ba8f7f12d626cf999cbbc6540c2be831a694936507dbf7262dd6d1879c9d0083110c2290b9ff977b4148f07fec335d188fde7b77c917e9eb6a03c910a81d67e80332db728c25c967a098e65e7f4ad3705ef88fa41020c0c00611e4f65aa5cd7a0db8c91201894c44afd98434b3f9e5b3b0d7ff0b4633f86cae16eb933be96e0d00f08a2b633f87cdf869116a9cdd611c361d803bc81c8d76e17c704bad6e7fcbafd70f52feea7cbf6b408350321c2946764bcc108b4b8e7636448b62701899ef05c748ffa9a3f938614d361da124499e5783b101849fc2aa95e1cc046873f479224b29c02a36c23103d5b74cfd8cce4c660d6cacdcdb12f0139b5aab61e159d4bbe3ca889893a4a9288577de6ac2b3832af5557cd6f3133db5c308208d341db191ba628f642844cd592a6e676c7c0f02b2face1e4bfddd8d9a40b83de8368ef07a9423389dc221280aa6666535b6120fe8f6df005435ee762ea0e9bd7958259e19268192c8091ab158afaa1a363ef3b4e98831bae5b6634f39c2f15f8d69c73f74b137224a1a21ae940228b6fd0670540546727604a05b7985ad9077403b05d989d026af9105474155384eb346391431aa725060635cbc7529e3e36fb18fe005047a23eb3302addaa5ff3687c54bb617c8d154d24f29897f6eaa58c1c6963fbeabdc452ce5651bbb036d81d3b8879a0bb8bdbf2f4aec3a062c56a1fc3ab945ddb602024665cdcc7c1fbe96fc9d3b76b4fa0e2a88092dfa38782f59a4722dd23251eb1d09dc635f0ca27a49556afe76573cf8704ee4115b30d88fa5f6f47eca8655c881e12e6775ece1a19dad0cb8344e1bf726fb8eefc1d098d45d783da48eb1fcfb2880d931bc37ebe1b58916a424dd0bfcb3ff17df4300f6a56649adcd4b0c7a434bebeefd94536117f77efc5062ee35ea739cae891a406997ef4a0494bc1f4b6bedd2623aa36994d62cd34936a3bfbd83006fb30b37217234e10a94ff9801db67cbc83f38960ffbeb1e6dc424b2d17fe2a03dec0a8f549df7e02abe7ef5dbd2d74ab5823cbc5c564ba255eda3a1c10f983988828c6426a56346169d5dfd6a680ea0d4af280286f9619b5279badd03c1b276bd807d4ff0619f768b31473c58401eeefa7515870dd2abf69109e1b3e8aec195514f68f52e0bbdd158e4b348e21f74392962b677e5dc2ebc96396e9a8be88f9cfb396443117dd5ceb5bcf42261a2ac109c5e602ae175108f717a715bac38700b7937b17b4785ceeb267d3d6c8f709e30d6c84f57f10ad7e61307cd9970b0fff0414f0eef1e9ea3e52437dac7ea7ce5256250c3bf14d9eeb9998f36653f9b6fbc00e4a696807738ab3666eb9aa98eb36dea3d853f90d652a58e3b735194be8f9cca5f2a638d6ea724bdf28509cf52856bb6f76ac25b3a65ee3c5c1e2107c96b7c9886c6ee651a5fdb30d3db7aff6c04fdc568009d044aab19bc1c58ad6fa6d78c9236210134eae71b34ad3524e249bd052f2081a4f0ba28a427b9c16b3b06", "little")
v = int.from_bytes(b"68c0fb27bb1e787d8d47b5b0f4c560ab7bd8ffcb8a17ebaf6a5df889c1df85e3e8afb6cc2e804210f4130860e7944df45c9194dd5fada062bdd306fc21acb2deeaef413f88daea6b7bdbfabcbfb265f5aeed0c29c079475812b81c5ed3ea646d881f170067ba63a9f85d7dd98f8716570fffba2faea7f50153932ad1a2529e0d6fef27c63d949045fc97ec9881ae925e6dbd41ccd003379b49653ed0cb4559df5dcfce8759d5d4b3e7080fde97340b79a81902fcd0243bdcc8236c5afbe6f883f2b7d7a82fb1c9ca61a0aff7b554f160e6c675cf14d78a8ab6db86b7301d831fea71d8cb41e65501ae067dbaaaa187ba2dd1b66f359280732416ecf3481f3b02932923cac0d2a87237cbc3a936340551039525c3fed3be4364cadabcca9dc54cc8ca6188edd762ea08bf49168317e1317a8659bb38070383575afbe6abb24cd618763c6fe5ab419761cf733f664d8760182e8be6624cf9018e44de5647bbc514eb5e8e488528443c45eaa4f738c61f43b3e5b5bd6a6d617f83bd081df5e6a19c45f3bc8822172e1c4be1a94c195caaa4cf4c4c0b7b4b1beaf37d892ede370a7b017b460fa318b194d1bb102c7a92e5756f218ae81e4c51f0ef1664ede0875229668d31946f5bc8e7415b9e84d36ef4cdee703331dc22725a3fd39eb50cca79a849677e5ebdc3c3d31b9346725760892bd07cfc53a4a82ef6a2aacb378ed4aac07bc9bad30a1f7a001d63eda09d773e03bfd631917e91944bccf27f162e6cf728df7333cb5a8610416aee274b25ef192e28d5b0a172f527667f51c0d74e2edb719757652b18e15d41f78f358299ea4b06abcb3102589096372fd9e416662435259c1d252c213c54c2f4ae96e3374f3691d27af0742f3295cbbb9942d985dbf1a60398a0a3747adffe2f0c7bccf3e6c85ea14181ee84b69dfc02ea0c579ce9ff883e6dbf058065b182b9769246fb5e60ba8af97d3982192cc51544a6637b615b3dc7b573e0244069ac78e27555170fe299422c93d9a56174e0a2dc1e426ff0aa7804803f96abf9e951f57329b60e6a58de30804f927fe459870e38230dbec7498d682ec0caad9edcd162e1c0cc9ba4dea22f8112d4f702d55a1ab2d4fd8ad70e5ae8a4bd0b0961fca54665ad436cf96fd23d10da7011909517f5460123877fb16dfafb28fb417d53bab2514bd9c0c579ab07ad59e14520923e09dffe51d9133fbae56f452d25f382575aedc74c078331175278d05300f5d3e7a586c2a246dc61d6e071a6c052f2b5b0fab85891e2d527bc68973116cc9b7774508ab20303aef3b3ed04ae47348282b7cc0e3aabc2a764deec925193898bc6f9f7fb0f50c35fb2ad04bc0a6fef17d5697c92225c0f18bb76685c756d504b8a09f144af15a422b7d3bb022e0fc5a1cd8dca96ee4aed296126cc8cfc0cdaeae068513d3399bc203395f4c38caaa956056109bf67d3e2b5f745c6485de075a1bf2081bf450a129cb5670bcb1f2be2a800b954b1689abe2b7422e76227a4e5527c1760fa89e1583949a48e3812b6eea55bb1821ba450ff0ccaf81e1fa97f8c15f120163cc9b4c98dcfaae8cd47cf044145efefba9cc2ba75a5d6954b2dc2297865dce2dbbabdcfffc11b6bf20ea97d33ee1f5955dc250b7127550f1f3a7dee1154adc804c6eb1d3e0172b472a4f989700d09058b5cca8eb2f5d7d459d91b5aea52a0240110ef608fbda9338de7d6d88200467dc8424e67df39461c5937b728eed6e9da83c509bd50234efe8322351f321ce0754fc22f39e1b6db530e4bf5437ede20da2161e6788e6160ba87bc277c365b2da344861d1ca371273c294a1084a927ce741fd8828d4412b242f8f5881315a9662ff096399d1a23585abbd60d3a4d4d6519dc082610ee86458db20d8e51043079661b617b78da43e6cb12321f474dd0cfa8258c885e33a63f21aaf54d954bcb316ce1c200d9a40e06a0be710c842b245831d2c19f1f679cffe473d6c96d817ac8e72f18e41c0dd7d705deda97548ad0c8bf35b73ec15ba3500dfc3a77bee0d9d364eaf97706b32b32a0c137c1603d36c3c38b6fc658e928f0ddbffd6b2b657a7e58008b683ba02dd2bb82b102014b1f2a227eef5c0dce48a9dc085bd2663f4e56811827849347a24ae70b1ebc653cd2023457e07c86792992249f58acd7bd161606628c2282e9d243299638c86d68bb93e32f268ed84c9378031363561a14dd54b576e46a4c4dc0297e04aace19d61329d8a6b005230fd09ec7fb76976a50803927e7b064d21a99b24640c8b778c272f3c02e605d6d638821e919c3fcfea63dc9f82db9ee9eee3974228f95b47c035a01c367ad0182740e2b37bca8fdb74801fcd05e3efbfb1463fcdefdc71a2f0455e2eb8f1badc51c90d4fa260d8c6413ca95b6e2f9f61bf8a3889f46e1e2032a992bfc7137ef8579611faf1c2dd82509bd7cc43658d8491931ea2e1cea4ed17285a89aeb35be2de89ac42781ead4e4fca087755118ed6bcb5bb1242968b81c995f53e9dc469e2ee6d0846b8587986256966ae727dce7a2984c29ce3aa26ceba350e53cfc39a234633274a29ea756705b404873d97f6e25a108f3c699dbde0c501357b8874e9276bfeff10ce45b0420fa8e4a5c8b35b055d3edbba95bdf438359e14ed148afba77f690495f9ad07e018009ab7b3dfa5891adf94ecb6b9255c7dc51185e55287d900b6f7c9c2674d7ff45356e3eb4fdc0211463c1af93110d412866f04ff1e7bb70107ab93668d05ef8b718bbf9bb5f892f690e7a7155addea6f9d74c9e48d37cb62144cbeaf0468d2dd5e565da5e86ba35a441d0c1b3192a675999f61b4249be865a03bc8e590599fa184e7fd9b98098d00ef12f764345d38b5c0880d2c8ba11d18756dc0970db12dea6b717ad044b788af3c55abf5d64463adffa59177e5ef081feab736634935feea76556596df28d982c3c520ea349568375e897ad0c486116b780ffed096e3bb6911ea7c86ac41408e37d30ffe26eaa0b37d8b075b0b6d1dbb79e211a2d9a3ca4403ef46c760c08eb2ee2d0cb7c0639337738e5d47fae434c1a72b4156e8514d346b29fe7b45933afdc5ec8d46d44b11fc8689e15bd58af1c87505103", "little")

# 计算共享密钥
shared_key = hashlib.sha512(m).digest()[:32]

print("计算出的共享密钥:", shared_key.hex())