package controller

import (
	"bytes"
	"crypto/ecdsa"
	"encoding/hex"
	"engineer_station_server/config"
	"engineer_station_server/sdk"
	"engineer_station_server/service"
	"engineer_station_server/utils"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/tjfoc/gmsm/sm2"
	"github.com/tjfoc/gmsm/sm3"
)

type AuthType string

const (
	AuthTypePassword  AuthType = "password"
	AuthTypeSymmetric AuthType = "symmetric"
	AuthTypeSignature AuthType = "signature"
)

type LoginReq struct {
	AuthType AuthType `json:"auth_type" binding:"required,min=1,max=256"`

	Username string `json:"username" binding:"required,min=1,max=256"`

	Password string `json:"password" binding:"omitempty,min=1,max=1024"`

	Challenge string `json:"challenge" binding:"omitempty,min=64,max=64"`
	AuthInfo  string `json:"auth_info" binding:"omitempty,min=1,max=1024"`
}

var authHandlers = map[AuthType]func(*gin.Context, *LoginReq){
	AuthTypePassword:  handlePassword,
	AuthTypeSymmetric: handleSymmetric,
	AuthTypeSignature: handleSignature,
}

var (
	certService = service.NewCertService()
)

func LoginHandler(c *gin.Context) {
	var req LoginReq
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	handler, ok := authHandlers[req.AuthType]
	if !ok {
		c.JSON(http.StatusBadRequest, gin.H{"error": "不支持的认证方式"})
		return
	}
	handler(c, &req)
}

func handlePassword(c *gin.Context, req *LoginReq) {
	if len(req.Password) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	userInfo, err := sdk.GetUserInfo(req.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "从账号管理服务器获取用户信息失败"})
		return
	}
	if userInfo == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "用户不存在"})
		return
	}

	if userInfo.Role != sdk.RoleUser {
		c.JSON(http.StatusBadRequest, gin.H{"error": "该用户不支持所选登录方式"})
		return
	}

	if len(userInfo.PasswordHash) == 0 {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中口令哈希值不合法"})
		return
	}
	passwordHashBytes, err := hex.DecodeString(userInfo.PasswordHash)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中口令哈希值不合法"})
		return
	}

	salt, ok := config.SaltByUsername[userInfo.Username]
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "盐值错误"})
		return
	}
	saltBytes, err := hex.DecodeString(salt)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "盐值错误"})
		return
	}

	hashValue := sm3.Sm3Sum(append([]byte(req.Password), saltBytes...))
	if !bytes.Equal(passwordHashBytes, hashValue) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "口令有误"})
		return
	}

	// 获得 flag1
	ObtainFlag1()

	// 登录成功后调用
	token, err := utils.GenerateToken(req.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "令牌生成失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"token": token})
}

func handleSymmetric(c *gin.Context, req *LoginReq) {
	if len(req.Challenge) == 0 || len(req.AuthInfo) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	challengeFromReq, err := hex.DecodeString(req.Challenge)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	if _, err = hex.DecodeString(req.AuthInfo); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	userInfo, err := sdk.GetUserInfo(req.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "从账号管理服务器获取用户信息失败"})
		return
	}
	if userInfo == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "用户不存在"})
		return
	}

	if userInfo.Role != sdk.RoleAdmin {
		c.JSON(http.StatusBadRequest, gin.H{"error": "该用户不支持所选登录方式"})
		return
	}

	// 公钥加密的身份认证密钥密文（格式为：C1C3C2。C1 非压缩）
	if userInfo.EncryptedAuthKey == "" {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中身份认证密钥密文不合法"})
		return
	}
	authKeyCiphertextBytes, err := hex.DecodeString(userInfo.EncryptedAuthKey)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中身份认证密钥密文不合法"})
		return
	}
	if len(authKeyCiphertextBytes) != 113 {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中身份认证密钥密文不合法"})
		return
	}

	// 调用密码机的 SDF_ImportKeyWithISK_ECC 接口，将认证密钥密文导入密码机。密码机内部私钥索引为 1
	authKeyHandle, err := sdk.ImportKeyToHSM(1, authKeyCiphertextBytes)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中身份认证密钥密文不合法"})
		return
	}

	challenge := GetChallenge(req.Username)
	if !bytes.Equal(challengeFromReq, challenge) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "挑战值已过期，请重新获取挑战值"})
		return
	}

	// 调用密码机的 SDF_Decrypt 接口，解密鉴别信息，并去掉填充。
	decryptedData, err := sdk.SM4ECBDecryptAndPKCS7UnPaddingFromHex(authKeyHandle, req.AuthInfo)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "鉴别信息有误"})
		return
	}

	if !bytes.Equal(decryptedData, challenge) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "鉴别信息有误"})
		return
	}

	// 获得 flag1
	ObtainFlag1()

	// 登录成功后调用
	token, err := utils.GenerateToken(req.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "令牌生成失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"token": token})
}

func handleSignature(c *gin.Context, req *LoginReq) {
	if len(req.Challenge) == 0 || len(req.AuthInfo) == 0 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	challengeFromReq, err := hex.DecodeString(req.Challenge)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	if _, err := hex.DecodeString(req.AuthInfo); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "参数不合法"})
		return
	}

	userInfo, err := sdk.GetUserInfo(req.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "从账号管理服务器获取用户信息失败"})
		return
	}
	if userInfo == nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "用户不存在"})
		return
	}

	if userInfo.Role != sdk.RoleSuperAdmin {
		c.JSON(http.StatusBadRequest, gin.H{"error": "该用户不支持所选登录方式"})
		return
	}

	if len(userInfo.Cert) == 0 {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中证书不合法"})
		return
	}

	challenge := GetChallenge(req.Username)
	if !bytes.Equal(challengeFromReq, challenge) {
		c.JSON(http.StatusBadRequest, gin.H{"error": "挑战值已过期，请重新获取挑战值"})
		return
	}

	cert, err := certService.LoadCertificate(userInfo.Cert)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中证书不合法"})
		return
	}
	err = certService.ValidateCertificate(cert, service.RootCert)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中证书不合法"})
		return
	}

	ecdsaPubKey, ok := cert.PublicKey.(*ecdsa.PublicKey)
	if !ok {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "账号管理服务器中证书不合法"})
		return
	}
	sm2PubKey := sm2.PublicKey{
		Curve: ecdsaPubKey.Curve,
		X:     ecdsaPubKey.X,
		Y:     ecdsaPubKey.Y,
	}

	_, err = utils.ValidateSignature(req.Challenge, req.AuthInfo, &sm2PubKey)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "鉴别信息有误"})
		return
	}

	// 获得 flag1
	ObtainFlag1()

	// 登录成功后调用
	token, err := utils.GenerateToken(req.Username)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "令牌生成失败"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"token": token})
}
