package shangmibei

import (
	"config"
	"crypto/subtle"
	"encoding/hex"
	"log"

	"golang.org/x/crypto/chacha20poly1305"
)

/*
* 校验用户token是否合法
 */
func IsLogTokenMatch(hexToken string) map[string]any {
	result := make(map[string]any)
	result["is_match"] = false
	hexChallenge := GetLogChallengeHexFromSession()
	data, _ := hex.DecodeString(hexChallenge)
	var tmpToken = GenLogTokenHex(data)
	if hexToken == "" || len(tmpToken) != len(hexToken) {
		result["msg"] = "验证不通过"
		return result
	}
	var match = subtle.ConstantTimeCompare([]byte(tmpToken), []byte(hexToken)) == 1
	if match {
		log.Printf("身份验证成功 %v\n", match)
		result["is_match"] = true
		result["msg"] = "验证通过"
	} else {
		result["msg"] = "验证不通过"
	}
	return result
}

func GenLogTokenHex(challengeByte []byte) string {
	key, _ := hex.DecodeString(config.LogKeyHex)
	nonce, _ := hex.DecodeString(config.LogNonceHex)
	aead, err := chacha20poly1305.New(key)
	if err != nil {
		return ""
	}
	plaintext := []byte("")
	additionalData := challengeByte
	tag := aead.Seal(nil, nonce, plaintext, additionalData)
	hexTag := hex.EncodeToString(tag)
	return hexTag
}

func GenerateLogChallengeHex() string {
	tmpChallenge, _ := generateSecureAlphanumeric(48)
	hexChallenge := hex.EncodeToString([]byte(tmpChallenge))
	return hexChallenge
}
