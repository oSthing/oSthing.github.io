package shangmibei

import (
	"crypto/subtle"
	"encoding/hex"
	"strings"
	"unicode"

	"golang.org/x/crypto/chacha20poly1305"
)

const keyHex = "d0eb801593baacc3001025e6ce26e0cb855d26766970e82b0f9e3712ecd9ea15"
const nonceHex = "bd17a47f94bf6ebd8ec876c7"

/*
* 校验用户口令登录是否合法
 */
func UserLogin(username string, password string) map[string]any {
	result := make(map[string]any)
	hash := GetAuthHash(username)
	result["msg"] = "验证不通过"
	result["hash"] = hash
	result["is_match"] = false
	if "LogAdmin" != username {
		result["msg"] = "用户名不存在"
		return result
	}
	// 检查口令是否仅为可打印字符（不包含空格）
	if len(password) < 8 || len(password) > 16 || strings.Contains(password, " ") {
		result["msg"] = "口令要求：[8-16]个可打印字符(不包含空格)"
		return result
	}
	for _, r := range password {
		if !unicode.IsPrint(r) {
			result["msg"] = "口令要求：[8-16]个可打印字符(不包含空格)"
			return result
		}
	}
	key, _ := hex.DecodeString(keyHex)
	nonce, _ := hex.DecodeString(nonceHex)
	aead, err := chacha20poly1305.New(key)
	if err != nil {
		return result
	}
	plaintext := []byte("")
	additionalData := []byte(password)
	tag := aead.Seal(nil, nonce, plaintext, additionalData)
	tagString := hex.EncodeToString(tag)
	var match = subtle.ConstantTimeCompare([]byte(tagString), []byte(hash)) == 1
	if match {
		result["msg"] = "验证通过"
		result["is_match"] = true
		return result
	}
	return result
}
