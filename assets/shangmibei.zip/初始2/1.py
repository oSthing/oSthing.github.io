from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import struct

def encrypt_card_data(item) -> str:
    result = f"{item.card},{item.pin},{item.id}"
    plaintext = result.encode('utf-8')
    key = get_key()
    # item.index 数据序号
    nonce = get_iv_byte(item.index)
    tmp = encrypt(key,nonce,plaintext).hex()
    return tmp

def get_iv_byte(index: int, prefix=b'', length=16) -> bytes:
    if not (0 <= index < 2**32):
        raise ValueError("Index 必须在 0 到 2^32-1 之间")
    index_bytes = struct.pack('>I', index)
    pad_len = length - len(prefix) - len(index_bytes)
    if pad_len < 0:
        prefix=b''
        pad_len = length - len(index_bytes)
    return prefix + (b'\x00' * pad_len) + index_bytes

def encrypt(key,nonce,plaintext) -> bytes:
    algorithm = algorithms.SM4(key)
    mode = modes.CTR(nonce)
    cipher = Cipher(algorithm, mode)
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(plaintext) + encryptor.finalize()
    return ciphertext 

# 某系统加密重要数据，已知数据加密实现的核心代码、部分密文数据、部分明文数据。请破解出序号1002所对应的银行卡号与PIN码，并提交答案。