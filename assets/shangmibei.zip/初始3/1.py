"""

参数:
    n     = 17669   (环维度，要求为素数（保证 X^n-1 在 GF(2) 上仅有两个不可约因子）)
    k     = 16      (消息长度，字节)
    n1    = 46      (外码 RS[46, 16, 31] 的码长)
    n2    = 384     (内码重复 RM 的码长（RM(1,7)×3 = [384, 8, 192]）)
    delta = 15      (RS纠错能力)
    w     = 66      (私钥向量 x, y 的 Hamming 重量)
    w_r   = 75      (随机向量 r1, r2 的 Hamming 重量)
    w_e   = 75      (误差向量 e 的 Hamming 重量)
    级联码结构：RS[46,16,31] over GF(2^8) ⊗ RM(1,7)×3
"""

import os, hashlib, random, reedsolo
from typing import Tuple, List

# ============================================================
# 参数
# ============================================================
PARAM_N     = 17669     # 环 R = GF(2)[X]/(X^17669 - 1) 的维度
PARAM_K     = 16        # 消息长度 (字节)
PARAM_N1    = 46        # 外码 RS[46, 16, 31] 的码长
PARAM_N2    = 384       # 内码重复 RM 的码长（RM(1,7)×3 = [384, 8, 192]）
PARAM_DELTA = 15        # RS可纠错数
PARAM_W     = 66        # 私钥向量 x, y 的 Hamming 重量
PARAM_W_R   = 75        # 随机向量 r1, r2 的 Hamming 重量
PARAM_W_E   = 75        # 误差向量 e 的 Hamming 重量
PARAM_RM_M  = 7         # RM(1,m) 
PARAM_RM_LEN = 128      # RM(1,7) 码长 = 2^7
PARAM_REP   = 3         # RM 码重复次数

# GF(2^8) 不可约多项式: x^8 + x^4 + x^3 + x^2 + 1 = 0x11D
GF256_MOD = 0x11D

# ============================================================
# Reed-Muller RM(1,7) 编码与解码
# ============================================================
# RM(1,7) 是一阶 Reed-Muller 码，参数为 [128, 8, 64]：
#   码长  n = 2^7 = 128
#   维度  k = 1 + 7 = 8（常数项 + 7 个坐标函数）
#   最小距离 d = 2^(7-1) = 64

def rm17_encode(symbol: int) -> int:
    """
    RM(1,7) 编码：8 位符号 → 128 位码字。
    符号格式：bit7 = 常数项，bits[6:0] = 线性项系数。
    """
    codeword = 0
    const_bit = (symbol >> 7) & 1  # 最高位 = 常数项
    for pt in range(128):  # 在所有点评估仿射函数
        val = const_bit
        for bit in range(7):
            if (symbol >> bit) & 1:
                val ^= (pt >> bit) & 1
        if val:
            codeword |= (1 << pt)
    return codeword

def rm17_decode(codeword: int) -> int:
    """
    RM(1,7) 解码：128 位码字 → 8 位符号（Walsh-Hadamard 变换）。
    """
    # Map {0,1} -> {+1,-1}
    signal = [1 - 2 * ((codeword >> i) & 1) for i in range(128)]
    # 快速Walsh-Hadamard变换
    wht = list(signal)
    h_step = 1
    while h_step < 128:
        for i in range(0, 128, h_step * 2):
            for j in range(i, i + h_step):
                x, y = wht[j], wht[j + h_step]
                wht[j], wht[j + h_step] = x + y, x - y
        h_step *= 2
    # 找到绝对值最大值
    best_idx = max(range(128), key=lambda i: abs(wht[i]))
    sign_bit = 1 if wht[best_idx] < 0 else 0
    return (sign_bit << 7) | best_idx

# ============================================================
# 重复 Reed-Muller 码 [384, 8, 192] = RM(1,7) × 3
# ============================================================
# 将 RM(1,7) 码重复 3 次：
#   编码：128 位码字复制 3 份，拼接为 384 位
#   解码：将 3 份 128 位段逐位取多数表决（bitwise majority vote），
#          再调用 RM(1,7) 解码
# 重复设计将最小距离从 64 提升至 192，代价是码率降低为 1/3

def dup_rm_encode(symbol: int) -> int:
    """重复 RM(1,7)×3 编码：8 位符号 → 384 位码字。"""
    base = rm17_encode(symbol)
    return base | (base << 128) | (base << 256)

def dup_rm_decode(bits: int) -> int:
    """重复 RM(1,7)×3 解码：384 位码字 → 8 位符号。"""
    mask = (1 << 128) - 1
    seg0 = bits & mask
    seg1 = (bits >> 128) & mask
    seg2 = (bits >> 256) & mask
    # 按位多数表决
    majority = (seg0 & seg1) | (seg1 & seg2) | (seg0 & seg2)
    return rm17_decode(majority)

# ============================================================
# Reed-Solomon RS[46, 16, 31] over GF(2^8)
# ============================================================
# RS 码参数：
#   码长  n1 = 46，信息位 k = 16，最小距离 d = 31
#   纠错能力 δ = (d-1)/2 = 15 个 GF(2^8) 符号
# 系统码形式：码字 = [消息符号 | 校验符号]，前 16 个符号即为原始消息
_rs_codec = reedsolo.RSCodec(nsym=PARAM_N1 - PARAM_K, fcr=1, c_exp=8)  # 默认 GF(2^8)

def rs_encode(msg: bytes) -> List[int]:
    """编码：消息 -> 系统码码字（消息 + 校验）"""
    if len(msg) != PARAM_K:
        raise ValueError(f"消息长度必须为 {PARAM_K} 字节")
    encoded_bytes = _rs_codec.encode(msg)
    return list(encoded_bytes)

def rs_decode(symbols: List[int]) -> bytes:
    if len(symbols) != PARAM_N1:
        raise ValueError(f"接收码字长度必须为 {PARAM_N1} 个符号")
    received_bytes = bytes(symbols)
    try:
        # 兼容不同版本 reedsolo 的返回值
        decoded_bytes = _rs_codec.decode(received_bytes)[0]
    except reedsolo.ReedSolomonError as e:
        raise ValueError(f"RS解码失败：{e}") from e
    return decoded_bytes[:PARAM_K]

# ============================================================
# 级联码 Concatenated Code 编码与解码
# ============================================================
# 编码流程（外码先行）：
#   16 字节消息
#   → RS[46,16,31] 外码编码 → 46 个 GF(2^8) 符号
#   → 每个符号经 dup_rm_encode → 46 × 384 = 17664 位
#   → 嵌入 n=17669 维环 R 中
#
# 解码流程（内码先行）：
#   17664+ 位码字
#   → 按 384 位分组为 46 组，每组经 dup_rm_decode → 46 个 GF(2^8) 符号
#   → RS 解码（综合征检验 + 可选 BM 纠错）→ 16 字节消息

def concat_encode(msg: bytes) -> int:
    """级联码编码：16 字节消息 → 17664 位码字（Python 整数形式）。"""
    rs_symbols = rs_encode(msg)
    codeword = 0
    for i, sym in enumerate(rs_symbols):
        inner = dup_rm_encode(sym)
        codeword |= (inner << (i * PARAM_N2))
    return codeword

def concat_decode(codeword: int) -> bytes:
    """级联码解码：17664+ 位码字（Python 整数）→ 16 字节消息。"""
    symbols = []
    for i in range(PARAM_N1):
        chunk = (codeword >> (i * PARAM_N2)) & ((1 << PARAM_N2) - 1)
        symbols.append(dup_rm_decode(chunk))
    return rs_decode(symbols)

# ============================================================
# 多项式环 R = GF(2)[X]/(X^n - 1) 上的运算
# ============================================================
# 全部公钥/密文运算均在此环上进行。
# 元素以 Python 整数表示：第 i 位对应 X^i 的系数。
# 重要性质：
#   加法 = XOR（GF(2) 特征为 2，加减等价）
#   乘法 = 循环卷积（模 X^n - 1 的多项式乘法）
#   公钥 s = x + h·y 的安全性依赖于求解 QCSD 问题的困难性

def poly_add(a: int, b: int) -> int:
    return a ^ b

def poly_mul_mod(a: int, b: int, n: int = PARAM_N) -> int:
    """
    循环多项式乘法：(a · b) mod (X^n - 1)。
    实现策略：枚举 a 的非零位（稀疏乘法），对 b 施加相应的循环移位后 XOR 累加。
    时间复杂度 O(wt(a) · n)，适合 Hamming 重量较小的向量（如私钥和随机向量）。
    """
    result = 0
    mask = (1 << n) - 1
    # 优化：遍历a的置位
    temp = a
    i = 0
    while temp:
        if temp & 1:
            shifted = b << i
            result ^= (shifted & mask) ^ (shifted >> n)
        temp >>= 1
        i += 1
    return result & mask

def poly_weight(a: int) -> int:
    return bin(a).count("1")

def poly_to_bytes(p: int) -> bytes:
    return p.to_bytes((PARAM_N + 7) // 8, "little")

def poly_from_bytes(data: bytes) -> int:
    return int.from_bytes(data, "little") & ((1 << PARAM_N) - 1)

# ============================================================
# 随机向量采样
# ============================================================
# 安全性要求密钥和随机向量的 Hamming 重量精确固定。
# 采样算法：从 {0,...,n-1} 中均匀无重复地抽取 w 个位置，置为 1。

def sample_fixed_weight(n: int, w: int, rng=None) -> int:
    """采样 Hamming 重量恰好为 w 的随机二进制向量。"""
    if rng is None: rng = random.SystemRandom()
    positions = rng.sample(range(n), w)
    result = 0
    for p in positions: result |= (1 << p)
    return result

def sample_random_poly(n: int, rng=None) -> int:
    """采样均匀随机的 n 位多项式（用于公钥 h 的生成）。"""
    nbytes = (n + 7) // 8
    if rng is None:
        raw = os.urandom(nbytes)
    else:
        raw = bytes(rng.getrandbits(8) for _ in range(nbytes))
    return int.from_bytes(raw, "little") & ((1 << n) - 1)

# ============================================================
# 密钥生成/封装
# ============================================================

def keygen(seed: bytes = None) -> Tuple[dict, dict]:
    """
    密钥生成。
    公钥 pk = (h, s)：h 为均匀随机多项式，s = x + h·y
    私钥 sk = (x, y)：两个 Hamming 重量为 w 的低权重多项式
    安全性基于求解 2-QCSD 问题的困难性。
    """
    if seed:
        rng = random.Random(seed)
    else:
        rng = random.SystemRandom()
    h = sample_random_poly(PARAM_N, rng)
    x = sample_fixed_weight(PARAM_N, PARAM_W, rng)
    y = sample_fixed_weight(PARAM_N, PARAM_W, rng)
    s = poly_add(x, poly_mul_mod(h, y))
    return {"h": h, "s": s}, {"x": x, "y": y}

def encapsulate(pk: dict, m: bytes, r1: int, r2: int, e: int):
    h, s = pk["h"], pk["s"]
    u = poly_add(r1, poly_mul_mod(h, r2))
    v = poly_add(poly_add(concat_encode(m), poly_mul_mod(s, r2)), e)
    shared_key = hashlib.sha512(m).digest()[:32]
    return u, v, shared_key
    

#请选手破解此算法的共享密钥